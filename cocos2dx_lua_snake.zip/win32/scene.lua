return {
{x=-4,y=1,index=1},
{x=-4,y=-1,index=1},
{x=1,y=1,index=2},
{x=2,y=-2,index=3},
}
